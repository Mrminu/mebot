<p align="center">
<img src="https://telegra.ph/file/4612c9b64b34220828a63.jpg" width="200" height="200"/>
</p>
<p align="center">
    <a href="https://Botynyakamu.github.io">
        <img
            src="https://readme-typing-svg.herokuapp.com?size=21&width=280&lines=NUMPANG+KOK+BANGGA+NGAB+🗿?+"
            alt="rzy-botz"
        />
    </a>
</p>
</p>
<p align="center">
<a href="https://Botynyakamu.github.io"><img title="Creator" src="https://img.shields.io/badge/Creator-Rozi-purple.svg?style=for-the-badge&logo=github"></a>
<a href="https://BOTCAHX.github.io"><img title="Creator" src="https://img.shields.io/badge/Creator-BOTCAHX-purple.svg?style=for-the-badge&logo=github"></a>
<a href="https://AlyaaXd.github.io"><img title="Creator" src="https://img.shields.io/badge/Creator-Alya-purple.svg?style=for-the-badge&logo=github"></a>
<a href="https://github.com/siegrin"><img title="Creator" src="https://img.shields.io/badge/membantu-Luc-purple.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/Botynyakamu/followers"><img title="Followers" src="https://img.shields.io/github/followers/Botynyakamu?color=green&style=flat-square"></a>
<a href="https://github.com/Botynyakamu/Rzy/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Botynyakamu/Rzy?color=white&style=flat-square"></a>
<a href="https://github.com/Botynyakamu/Rzy/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Botynyakamu/Rzy?color=yellow&style=flat-square"></a>
<a href="https://github.com/Botynyakamu/Rzy/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Botynyakamu/Rzy?label=Watchers&color=red&style=flat-square"></a>
<a href="https://github.com/Botynyakamu/Rzy"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/Botynyakamu/Rzy/"><img title="Size" src="https://img.shields.io/github/repo-size/Botynyakamu/Rzy?style=flat-square&color=darkred"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FBotynyakamu%2FHaruka&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/Botynyakamu/Rzy/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-No-red.svg"></a>&nbsp;&nbsp;
</p>


## CARA INSTALL DI TERMUX
```bash
> termux-setup-storage
> pkg update && pkg upgrade
> pkg install git
> pkg install nodejs
> pkg install bash
> pkg install ffmpeg
> pkg install libwebp
> git clone https://github.com/Botynyakamu/Rzy-botz-M1
> cd Rzy-botz-M1
> npm i
> node run.js
# Untuk Sdcard (File Sudah Di Download)
> cd /sdcard
> cp -r Rzy-botz-M1 $HOME
> cd Rzy-botz-M1
> npm i
> node run.js
```

## Run Heroku
```bash
▸ Ketik di [CHROME]
https://github.com ( BUAT AKUN GITHUB DULU ) => sesuaikan Imail anda
https://heroku.com ( BUAT AKUN HEROKU DULU ) => sesuaikan Imail anda

▸ Untuk Sc nya cari sendiri, atau pakai sc ku ( SC KU SERING MENAMBAH FITUR )

▸ scan kode untuk mengambil session
1) Buka yt => Cara mengambil session tanpa termux atau bisa pakai replit di bawah
2) biasanya link untuk scan ada di pin komen
3) trus pakai mode desktop
4) ada di atas tombol yg hijau klik aja
5) terus tunggu beberapa menit sampai kode QR keluar
6) kalau dah keluar scan aja
7) session di kirim di WhatsApp centang ijo,kalian salin aja

▸ Github
8) kalau SC nya sudah ketemu kalian klik aja link SC nya
9) pakai mode desktop
10) trus fork di atas pojok kanan
11) matiin mode desktopnya 
12) tekan link yang ada nama github kalian
13) terus kalau udah klik yg view code
14) scrol bawah sampai ketemu tulisan session.data.json ( *KALAU GAK ADA TULISAN ITU BISA CHT OWNER SAYA* )
15) terus klik yang ada gambar pensil gitu kecil
16) pilih yang edit file
17) hapus session yang ada di situ
18) kalau udah di hapus, tempel session kamu
19) terus kalau udah geser ke bawah,trus pilih commit changed
20) klik tombol home 3 kali sampai kembali ke halaman utama github
21) edit aja yang lain"nya sendiri ( JANGAN SAMPAI ERORR )

▸ Penginstal :
Buka halaman HEROKU => https://heroku.com
 LIAT YT AJA,GW LUPA SOALNYA
( JAGAN LUPA BUILDPACK NYA )
```

Simple WhatsApp Bot

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/AlyaaXd/Haruno-Botz)



# Ambil [seesion.data.json] Di sini => JANGAN LUPA MODE DESKTOP

[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsAlfa)](https://replit.com/@zeeoneofc/SessionByZeeoneOfc?lite=1&outputonly=1#.replit)



# INSTALLL Buildpack
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip)
* [Libwebp](https://developers.google.com/speed/webp/download)


# THANKS TO 
 [`Baileys`](https://github.com/adiwajshing/Baileys)

 [`AlyaXzy`](https://wa.me/6289505165400)

 [`BOTCAHX`](https://wa.me/6282221792667)

 [`ZIFABOTZ`](https://wa.me/6285828764046)

## Whatsapp

[![Grup WhatsApp](https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/I8Q4oJVw8buHhIgMH5iVAv)
[![Rozi](https://img.shields.io/badge/WhatsApp%20Rozi-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/6285828764046/)
[![Owner Zifabotz](https://img.shields.io/badge/WhatsApp%20Ownerzifabotz-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/6285828530078/)

[![BOTCAHX](https://github.com/BOTCAX.png?size=100)](https://github.com/BOTCAHX) | [![ALYA](https://github.com/AlyaaXd.png?size=100)](https://github.com/AlyaaXd) | [![ZIFABOTZ](https://github.com/Botynyakamu.png?size=100)](https://github.com/botynyakamu)
----|----|----
[BOTCAHX](https://github.com/BOTCAX) | [ALYA](https://github.com/AlyaaXd) | [ZIFABOTZ](https://github.com/Botynyakamu)| [Luc](https://github.com/siegrin)
 Penulis / Pencipta | Penulis / pencipta | Penulis / pencipta | membantu

# Hargai Kami Dengan Menambahkan Kredit ( Wm ) 

~ Selamat Memakai Guys~
